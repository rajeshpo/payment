const braintree = require("braintree");

const gateway = new braintree.BraintreeGateway({
  environment: braintree.Environment.Sandbox,
  merchantId: "k33t8qngddspf8sw",
  publicKey: "r5yd6sp7g8mznrt2",
  privateKey: "a404e601507fff4af8a18b963ee25913"
});

exports.getToken=(req,res)=>{
    gateway.clientToken.generate({}, (err, response) => {
        // pass clientToken to your front-end
        if(err){
            res.status(500).send(err)
        }
        else{
            res.send(response)
        }
        
      });
}

exports.processPayment=(req,res)=>{
    let nonceFromTheClient=req.body.paymentMethodNonce;
    let amountFromTheClient=req.body.amount;
    gateway.transaction.sale({
        amount:amountFromTheClient,
        paymentMethodNonce: nonceFromTheClient,
        
        options: {
          submitForSettlement: true
        }
      }, (err, result) => {
          if(err){
              res.status(500).send(err)
          }
          else{
              res.send(result)
          }
      })
}